import React, { useEffect, useState } from 'react';
import './Post.css';
export default function Dashboard() {
    const [posts, setPosts] = useState([
        { id: null, title: "", author: "" }
    ]);
    const [newTitle,setNewTitle] = useState("");
    const [selectedPost, setSelectedPost] = useState(null);
    const [editingPostId, setEditingPostId] = useState(null);
    const [editingTitle, setEditingTitle] = useState("");

    const fetchPosts = () => {
        setPosts([
            { id: 1, title: "Happiness", author: "John" },
            { id: 2, title: "MIU", author: "Dean" },
            { id: 3, title: "Enjoy Life", author: "Jasmine" }
        ]);
    };

    useEffect(() => {
        fetchPosts()
    }, [])   
    

    const handleChangeName = () => {
        if (newTitle.trim() !== "" && posts.length > 0) {
            const updatedPosts = [...posts];
            updatedPosts[0].title = newTitle;
            setPosts(updatedPosts);
            setNewTitle("");
        }
    };


    const handleDelete = (id) => {
        const updatedPosts = posts.filter(post => post.id !== id);
        setPosts(updatedPosts);
        if (selectedPost && selectedPost.id === id) {
            setSelectedPost(null); 
        }
    };

   
    const handleEdit = (id, currentTitle) => {
        setEditingPostId(id);
        setEditingTitle(currentTitle);
    };
  
    const handleSaveEdit = () => {
        const updatedPosts = posts.map(post => 
            post.id === editingPostId ? { ...post, title: editingTitle } : post
        );
        setPosts(updatedPosts);
        setEditingPostId(null); 
        setEditingTitle("");    
    };

    const handleSelectPost = (post) => {
        setSelectedPost(post);
    };

    return (
        <React.Fragment>          
            <div className="post-container">
                <h1>Dashboard</h1>
                <div className="post-cards">
                {posts.map((post) => (
                    <div className="post-card" key={post.id} onClick={() => handleSelectPost(post)}>
                        <p>Id: {post.id}</p>
                        <p>Title: {post.title}</p>
                        <p>Author: {post.author}</p>                     
                    </div>
                ))}
                </div>
                
                <br/>
        
            <div className="change-name-div">
                <input
                    type="text"
                    placeholder=" "
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                />
                <button onClick={handleChangeName}>Change Name</button>
            </div>

     
            {selectedPost && (
                <div className="post-details">
                    <h3><u>{selectedPost.title}</u></h3>
                    <p>{selectedPost.author}</p>
                    <p>This is the content in the post…</p>
                    <div className="post-actions">
                        {/* <button onClick={() => handleEdit(selectedPost.id, selectedPost.title)} className="edit">edit</button>
                        <button onClick={() => handleDelete(selectedPost.id)} className="delete">delete</button> */}
                    <a href="#" onClick={(e) => { e.preventDefault(); handleEdit(selectedPost.id, selectedPost.title); }} className="button-link">edit</a>
                    <a href="#" onClick={(e) => { e.preventDefault(); handleDelete(selectedPost.id); }} className="button-link">delete</a>
                    </div>
                </div>
            )}


            {editingPostId !== null && (
                <div className="edit-modal">
                    <h3>Edit Post Title</h3>
                    <input
                        type="text"
                        value={editingTitle}
                        onChange={(e) => setEditingTitle(e.target.value)}
                    />
                    <button onClick={handleSaveEdit}>Save</button>
                    <button onClick={() => setEditingPostId(null)}>Cancel</button>
                </div>
            )}

            </div>       
        </React.Fragment>
    );
}