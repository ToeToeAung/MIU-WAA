const Post = (props) => {
    return (
        <div className="post-card" >
            <p> {props.id}</p>
            <p> {props.title}</p>
            <p> {props.author}</p>         
                         
        </div>
    );
}

export default Post;