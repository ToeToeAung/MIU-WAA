package miu.edu.postapp.entity.dto;

public class PostDetailDto {
}
