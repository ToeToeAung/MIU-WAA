import React, { useEffect, useState,useContext,useRef } from 'react';
import './Post.css';
import { fetchService } from "../../services/fetchServices";
import selectedIdContext from "./SelectedId-Context";

export default function Dashboard() {
    const context = useContext(selectedIdContext);
    const selectedId = context?.id || 0;  
    const setSelectedId = context?.setId || (() => {});
    const [posts, setPosts] = useState([
        { id: null, title: "", author: "" }
    ]);
    const [newTitle,setNewTitle] = useState("");
    const [selectedPost, setSelectedPost] = useState(null);
    const [editingPostId, setEditingPostId] = useState(null);
    const [editingTitle, setEditingTitle] = useState("");
    const [showAddPostModel, setShowAddPostModel] = useState(false);
    const newTitleRef = useRef(null);
    const newAuthorRef = useRef(null);
    const newContentRef = useRef(null);
 
    useEffect(() => {
        fetchPosts()
    }, [])   
    
    const fetchPosts = async () => {
        setPosts(await fetchService.get("posts"));
    }

    const fetchPostById = async (id) => {
        const post = await fetchService.get(`posts/${id}`);
        setSelectedPost(post);
    };

    const handleChangeName = () => {
        if (newTitle.trim() !== "" && posts.length > 0) {
            const updatedPosts = [...posts];
            updatedPosts[0].title = newTitle;
            setPosts(updatedPosts);
            setNewTitle("");
        }
    };

    const openAddPostModel = () => setShowAddPostModel(true);
    const closeAddPostModel= () => setShowAddPostModel(false);
  
//     const handleAddPost = async () => {
//       const response = await fetchService.post('/posts', newPost);
//       console.log("Post "+response)
//       //if (response) {     
//         closeAddPostModel();
//         setNewPost({ title: '', author: '', content: '' }); 
//     //  } else {
//    //     console.log("Failed to add post");
//     //  }
//     };

    const handleAddPost = async () => {
        const newPost = {
            title: newTitleRef.current.value,
            author: newAuthorRef.current.value,
            content: newContentRef.current.value
        };
        const response = await fetchService.post('/posts', newPost);
      //  if (response) {
            closeAddPostModel();
            setPosts([...posts, response]);
            newTitleRef.current.value = '';
            newAuthorRef.current.value = '';
            newContentRef.current.value = '';
      //  } else {
      //      console.log("Failed to add post");
      //  }
    };

    const handleDelete = async (id) => {
        const url = `/posts/${id}`;
        const success = await fetchService.deleteData(url);    
        if (success) {
            const updatedPosts = posts.filter(post => post.id !== id);
            setPosts(updatedPosts);
            if (selectedPost && selectedPost.id === id) {
                setSelectedPost(null); 
            }
        } else {
            console.log("Failed to delete post");
        }
    };

     
    const handleEdit = (id, currentTitle) => {
        setEditingPostId(id);
        setEditingTitle(currentTitle);
    };
  
    const handleSaveEdit = () => {
        const updatedPosts = posts.map(post => 
            post.id === editingPostId ? { ...post, title: editingTitle } : post
        );
        setPosts(updatedPosts);
        setEditingPostId(null); 
        setEditingTitle("");    
    };

    const handleSelectPost = (post) => {
        setSelectedId(post.id);
        fetchPostById(post.id);
    };

    return (
        <React.Fragment>          
            <selectedIdContext.Provider value ={{id : selectedId}}>
            <div className="post-container">
                <h1>Dashboard</h1>
              
                <div className="post-cards">
                {posts.map((post) => (
                    <div className="post-card" key={post.id} onClick={() => handleSelectPost(post)}>
                        <p>Id: {post.id}</p>
                        <p>Title: {post.title}</p>
                        <p>Author: {post.author}</p>       
                        <div className="post-actions">                      
                           <a href="#" onClick={(e) => { e.preventDefault(); handleEdit(post.id, post.title); }} className="button-link">edit</a>
                           <a href="#" onClick={(e) => { e.preventDefault(); handleDelete(post.id); }} className="button-link">delete</a>
                        </div>              
                    </div>
                ))}
                </div>                
                <br/>    
                <button onClick={openAddPostModel} className="p-button">Add Post</button>
                <br/>    
            <div className="change-name-div">
                <input
                    type="text"
                    placeholder=" "
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                />
                <button className="p-button" onClick={handleChangeName}>Change Name</button>
            </div>

     
            {selectedPost && (
                <div className="post-details">
                    <h3><u>{selectedPost.title}</u></h3>
                    <p>{selectedPost.author}</p>
                    <p>This is the content in the post…</p>
                   
                </div>
            )}

            {editingPostId !== null && (
                <div className="edit-modal">
                    <h3>Edit Post Title</h3>
                    <input
                        type="text"
                        value={editingTitle}
                        onChange={(e) => setEditingTitle(e.target.value)}
                    />
                    <button onClick={handleSaveEdit}>Save</button>
                    <button onClick={() => setEditingPostId(null)}>Cancel</button>
                </div>
            )}


        {/* {showAddPostModel && (
        <div className="add-post-modal">
          <div className="add-post-form">
            <h2>Add New Post</h2>
            <input
              type="text"
              placeholder="Title"
              value={newPost.title}
              onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
            />
            <input
              type="text"
              placeholder="Author"
              value={newPost.author}
              onChange={(e) => setNewPost({ ...newPost, author: e.target.value })}
            />
            <textarea
              placeholder="Content"
              value={newPost.content}
              onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
            />
            <button className="p-button" onClick={handleAddPost}>Submit</button>
            <button className="p-button" onClick={closeAddPostModel}>Cancel</button>
          </div>
        </div>
      )} */}

{showAddPostModel && (
                        <div className="add-post-modal">
                            <div className="add-post-form">
                                <h2>Add New Post</h2>
                                <input ref={newTitleRef} type="text" placeholder="Title" />
                                <input ref={newAuthorRef} type="text" placeholder="Author" />
                                <textarea ref={newContentRef} placeholder="Content" />
                                <button className="p-button" onClick={handleAddPost}>Submit</button>
                                <button className="p-button" onClick={closeAddPostModel}>Cancel</button>
                            </div>
                        </div>
                    )}

      </div>    
    </selectedIdContext.Provider>   
    </React.Fragment>
    );
}