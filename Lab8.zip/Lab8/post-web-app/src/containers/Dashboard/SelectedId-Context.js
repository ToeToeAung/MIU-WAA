import React from 'react';
const selectedIdContext = React.createContext();
export default selectedIdContext;