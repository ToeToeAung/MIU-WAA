import './App.css';
import Dashboard from './containers/Dashboard/Dashboard';

function App() {
  return (
    <div className="App">
      <Dashboard/>
    </div>
  );
}
export default App;
