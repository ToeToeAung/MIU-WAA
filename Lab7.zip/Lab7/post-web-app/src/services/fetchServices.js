import { API } from "../config/api";

const get = async (url) => {
    try {
        let data = [];
        data = (await API.get(url)).data;
        return data;
    } catch (error) {
        console.log(error.message)
        return [];
    }
}

const post = async (url, data) => {
    try {
        const result = await API.post(url, data);
        return result.data;
    } catch (error) {
        console.error("Error with POST:", error);
        return null; 
    }
};

const edit = async (url, data) => {
    try {
        const result = await API.put(url, data);
        return result.data; 
    } catch (error) {
        console.error("Error with EDIT:", error);
        return null; 
    }
};


const deleteData= async (url) => {
    try {
        await API.delete(url);
        return true; 
    } catch (error) {
        console.error("Error with DELETE:", error);
        return false; 
    }
};

export const fetchService = {
    get,
    post,
    edit,
    deleteData
    //getMultipleEndpoints,
   // post
};