import Post from '../../components/Post/Post' 

const Posts = (props) => {    
    const posts = props.posts.map(p => {       
        <div className="post-cards">
        {posts.map((post) => (
            <Post key={post.id} id={post.id} title={post.title} author={post.author} />
        ))}
    </div>
    });
    return posts;
}

export default Posts;